#include <iostream>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <queue>
#include <stack>
#include <vector>
#pragma warning(disable:4996)
#define NODESIZE 21
#define MAX_ALIVE_CHESS_NUM 6
using namespace std;

struct node
{
	node()
	{
		this->nodeID = 0;
		this->connect = NULL;
	};
	node(int val)
	{
		this->nodeID = val;
		this->connect = NULL;
	};
	int nodeID;
	int role;
	node* connect;
};
struct player
{
	/*
		�W�誱�a�s��(id) = 1;
		�U�誱�a�s��(id) = 2;
	*/
	player(string s)
	{
		if(!strcmp(s.c_str(),"top"))//�W�誱�a�Ѥl�]�m(�]�m6�ӴѤl�b�ѽL�W���@�Ӧ�m
		{
			this->chess_position[0] = 4;//��0�ӴѤl�b�ѽL�s��4���I
			this->chess_position[1] = 0;
			this->chess_position[2] = 1;
			this->chess_position[3] = 2;
			this->chess_position[4] = 6;
			this->chess_position[5] = 3;

			for(int i = 0 ; i < MAX_ALIVE_CHESS_NUM ; ++i)
			{
				this->chess_space[i] = 5;//�C�@�ӴѤl����@�}�l���O5
			}
			this->id = 1;//player�s��
		}
		else//�U�誱�a�Ѥl�]�m
		{
			this->chess_position[0] = 14;
			this->chess_position[1] = 18;
			this->chess_position[2] = 19;
			this->chess_position[3] = 20;
			this->chess_position[4] = 16;
			this->chess_position[5] = 17;

			for(int i = 0 ; i < MAX_ALIVE_CHESS_NUM ; ++i)
			{
				this->chess_space[i] = 5;//�C�@�ӴѤl����@�}�l���O5
			}
			this->id = 2;//player�s��
		}
		this->current_alive_chess_num = MAX_ALIVE_CHESS_NUM;//���a�@�}�l�s�����Ѥl�ƶq���O6
	}
	int id;
	int current_alive_chess_num;//�Ӫ��a�ثe�ѭ��W���Ѥl�ƶq
	int chess_position[MAX_ALIVE_CHESS_NUM];//�Ӫ��a�C�ӴѤl��������m
	int chess_space[MAX_ALIVE_CHESS_NUM];//�Ӫ��a�C�ӴѤl����(���񦳴X�ӪŮ�)
};
struct tree
{
	tree()
	{
		this->value = 1e9;
		this->instruction_where = -1;
		this->instruction_to = -1;
		this->next = NULL;
	}
	tree(int value , int instruction_where , int instruction_to)
	{
		this->value = value;
		this->instruction_where = instruction_where;
		this->instruction_to = instruction_to;
		this->next = NULL;
	}
	int value;
	int instruction_where;
	int instruction_to;
	tree* next; 
};
struct state //possible_state
{
	state()
	{
		this->instruction_where = 0;
		this->instruction_to = 0;
	}
	state(int instruction_where , int instruction_to)
	{
		this->instruction_where = instruction_where;
		this->instruction_to = instruction_to;
	}
	int instruction_where;
	int instruction_to;
};

//--------------------------------------------------------------
//golbal variable
//--------------------------------------------------------------
node** Map = new node*[NODESIZE];//�a��
player* ai = new player("top");//�q��(�W��)�A�Ѥl�s�� = 1
player* p1 = new player("down");//���a(�U��)�A�Ѥl�s�� = 2
tree* game_tree = new tree();
state decision;//�M�����U�k
vector<state> possible_state;//�����i�઺����
bool vis[NODESIZE];
int d_min;//default value is 1e9
int Round;//�ĴX�^�X
int currentp1 = 15;//ai����center��l�I
int currentp2 = 17;//center��l�I
int currentpI = 5;//ai���center��l�I
int currentpII = 3;//center��l�I
int direction = 0;//AI��m 0�U1�W
//--------------------------------------------------------------
//function declaration
//--------------------------------------------------------------
void init();//��l��
void path_set();//���|�]�m
int calc_distance(node* start,node* end);//�p����I�����Z��
void distance_dfs(node* from,node* end,int d);//��calc_distance�I�s��dfs
void calc_space();//�p��Ҧ��I��space
int space_dfs(player* which_turn,node* n,int temp_space);//��calc_space�I�s��dfs
void judge_rule(player* which_turn);//�P�_�W�h
void move(player* which_turn,int which_node,int node_destination);//���@��A�����Ѥl(�ѽL�s��)�A�������(�ѽL�s��)
void build_game_tree(player* which_turn);
void evaluation_function();
void random_stupid_ai(player* which_turn);//�H����AI
void little_smart_ai();//���I�o����AI
void center();

//--------------------------------------------------------------
//test function declaration
//--------------------------------------------------------------
void printMap();

//--------------------------------------------------------------
//function declaration implement
//--------------------------------------------------------------
void printMap()
{
	//Map[i] for i = {1~25}
	//0:no chess on that pos
	//1:play1(top:O) has chess on that pos
	//2:play2(down:X) has chess on that pos
	printf("        %c�@%c�@%c		|	    0�@1�@2					\n",Map[0]->role == 1 ? 'O' : (Map[0]->role == 2 ? 'X' : '#'),Map[1]->role == 1 ? 'O' : (Map[1]->role == 2 ? 'X' : '#'),Map[2]->role == 1 ? 'O' : (Map[2]->role == 2 ? 'X' : '#'));
	printf("      /  \\ | /  \\	|	  /  \\ | /  \\					\n");
	printf("     /     %c     \\ 	|	 /     3     \\						\n",Map[3]->role == 1 ? 'O' : (Map[3]->role == 2 ? 'X' : '#'));
	printf("    /      |      \\	|	/      |      \\						\n");
	printf("    %c      %c      %c	|      4       5       6						\n",Map[4]->role == 1 ? 'O' : (Map[4]->role == 2 ? 'X' : '#'),Map[5]->role == 1 ? 'O' : (Map[5]->role == 2 ? 'X' : '#'),Map[6]->role == 1 ? 'O' : (Map[6]->role == 2 ? 'X' : '#'));
	printf("   / \\   / | \\   / \\	|     / \\    / | \\    / \\							\n");
	printf("  %c �@%c-%c�@%c�@%c-%c�@ %c	|    7 - 8- 9- 10-11-12-13						\n",Map[7]->role == 1 ? 'O' : (Map[7]->role == 2 ? 'X' : '#'),Map[8]->role == 1 ? 'O' : (Map[8]->role == 2 ? 'X' : '#'),Map[9]->role == 1 ? 'O' : (Map[9]->role == 2 ? 'X' : '#'),Map[10]->role == 1 ? 'O' : (Map[10]->role == 2 ? 'X' : '#'),Map[11]->role == 1 ? 'O' : (Map[11]->role == 2 ? 'X' : '#'),Map[12]->role == 1 ? 'O' : (Map[12]->role == 2 ? 'X' : '#'),Map[13]->role == 1 ? 'O' : (Map[13]->role == 2 ? 'X' : '#'));
	printf("   \\ /   \\ | /   \\ /	|     \\ /    \\ | /    \\ /						\n");
	printf("    %c      %c      %c	|      14     15      16						\n",Map[14]->role == 1 ? 'O' : (Map[14]->role == 2 ? 'X' : '#'),Map[15]->role == 1 ? 'O' : (Map[15]->role == 2 ? 'X' : '#'),Map[16]->role == 1 ? 'O' : (Map[16]->role == 2 ? 'X' : '#'));
	printf("    \\      |      /	|	\\      |      /						\n");
	printf("     \\     %c     /	|	 \\     17    /						\n",Map[17]->role == 1 ? 'O' : (Map[17]->role == 2 ? 'X' : '#'));
	printf("      \\  / | \\  /	|	  \\  / | \\  /				\n");
	printf("        %c�@%c�@%c		|	   18�@19�@20					\n",Map[18]->role == 1 ? 'O' : (Map[18]->role == 2 ? 'X' : '#'),Map[19]->role == 1 ? 'O' : (Map[19]->role == 2 ? 'X' : '#'),Map[20]->role == 1 ? 'O' : (Map[20]->role == 2 ? 'X' : '#'));
	getchar();
	
}

int calc_distance(node* start,node* end)//�p����I�����Z��
{
	d_min = 1e9;
	memset(vis,0,sizeof(vis));
	if(start->connect == NULL)
	{
		return 1e9;
	}
	distance_dfs(start,end,0); //dfs
	/*
	//test unit node
	node* s = Map[0];
	node* e = Map[2];
	printf("distance from %d to %d: %d \n",s->nodeID,e->nodeID,calc_distance(s,e));	
	getchar();
	//test all nodes
	for(int i = 0 ; i < NODESIZE ; ++i)
	{
		for(int j = 0 ; j < NODESIZE ; ++j)
		{
			node* s = Map[i];
			node* e = Map[j];
			printf("distance from %d to %d: %d \n",s->nodeID,e->nodeID,calc_distance(s,e));		
		}
		getchar();
	}
	*/
	return d_min;
}
void distance_dfs(node* from,node* end,int d)//��calc_distance�I�s��dfs
{
	node* find = Map[from->nodeID];
	if(vis[find->nodeID])return;
	if(d > d_min)
	{
		return;//prune the search tree
	}
	if(find->nodeID == end->nodeID)
	{
		d_min = d < d_min ? d : d_min;
		return;
	}
	vis[from->nodeID] = true;//for backtracking
	while(find->connect != NULL)
	{
		find = find->connect;
		
		if(!vis[find->nodeID])distance_dfs(find,end,d+1);
	}
	vis[from->nodeID] = false;//for backtracking
	
}
void calc_space()//�p��Ҧ��I��space
{
	//�p��p1�Ҧ��Ѥl��space
	for(int i = 0 ; i < MAX_ALIVE_CHESS_NUM ; ++i)
	{
		if(p1->chess_position[i] == -1) continue;//�Q�Y�����N���ΧP�_
		memset(vis,0,sizeof(vis));
		p1->chess_space[i] = space_dfs(p1,Map[p1->chess_position[i]],0);
		//printf("p1 ����%d�ӴѤl(�s��%d) space = %d\n",i,p1->chess_position[i],p1->chess_space[i]);
	}
	//�p��ai�Ҧ��Ѥl��space
	for(int i = 0 ; i < MAX_ALIVE_CHESS_NUM ; ++i)
	{
		if(ai->chess_position[i] == -1) continue;//�Q�Y�����N���ΧP�_
		memset(vis,0,sizeof(vis));
		ai->chess_space[i] = space_dfs(ai,Map[ai->chess_position[i]],0);
		//printf("ai ����%d�ӴѤl(�s��%d) space = %d\n",i,ai->chess_position[i],ai->chess_space[i]);
	}
}
int space_dfs(player* which_turn,node* n,int temp_space)//��calc_space�I�s��dfs
{
		node* ptr = Map[n->nodeID];
		node* current_pos = Map[n->nodeID];//for backtracking
		int space = temp_space;
		vis[current_pos->nodeID] = true;
		while(ptr->connect != NULL)
		{
			ptr = ptr->connect;
			if(Map[ptr->nodeID]->role == 0 && !vis[ptr->nodeID]) //�J��Ů�Aspace+1
			{
				vis[ptr->nodeID] = true;//�קK�Ӧ�m���ƭp��
				space++;
			}
			else if(Map[ptr->nodeID]->role == which_turn->id)
			{	
				if(!vis[ptr->nodeID])space = space_dfs(which_turn,ptr,space);
			}
		}
		vis[current_pos->nodeID] = false;//for backtracking
		return space;
}
void init()
{
	srand(time(NULL));
	d_min = 1e9;
	Round = 1;
	path_set();
}
void path_set()
{
	/*
		�W��Ѥl�s��(role)   = 1
		�U��Ѥl�s��(role)   = 2
		�S���Ѥl����m(role) = 0
	*/
	for(int i = 0 ; i < NODESIZE ; ++i)
	{
		Map[i] = new node();
		Map[i]->nodeID = i;
	}
	//--------------------------------------------------------------
	//���|�]�m:node 0 - 10
	//--------------------------------------------------------------
	//node 0
	node *ptr = Map[0];
	ptr->role = 1;
	ptr->connect = new node(1);
	ptr = ptr->connect;
	ptr->connect = new node(3);
	ptr = ptr->connect;
	ptr->connect = new node(4);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 1
	ptr = Map[1];
	ptr->role = 1;
	ptr->connect = new node(0);
	ptr = ptr->connect;
	ptr->connect = new node(2);
	ptr = ptr->connect;
	ptr->connect = new node(3);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 2
	ptr = Map[2];
	ptr->role = 1;
	ptr->connect = new node(1);
	ptr = ptr->connect;
	ptr->connect = new node(3);
	ptr = ptr->connect;
	ptr->connect = new node(6);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 3
	ptr = Map[3];
	ptr->role = 1;
	ptr->connect = new node(0);
	ptr = ptr->connect;
	ptr->connect = new node(1);
	ptr = ptr->connect;
	ptr->connect = new node(2);
	ptr = ptr->connect;
	ptr->connect = new node(5);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 4
	ptr = Map[4];
	ptr->role = 1;
	ptr->connect = new node(0);
	ptr = ptr->connect;
	ptr->connect = new node(7);
	ptr = ptr->connect;
	ptr->connect = new node(8);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 5
	ptr = Map[5];
	ptr->role = 0;
	ptr->connect = new node(3);
	ptr = ptr->connect;
	ptr->connect = new node(9);
	ptr = ptr->connect;
	ptr->connect = new node(10);
	ptr = ptr->connect;
	ptr->connect = new node(11);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 6
	ptr = Map[6];
	ptr->role = 1;
	ptr->connect = new node(2);
	ptr = ptr->connect;
	ptr->connect = new node(12);
	ptr = ptr->connect;
	ptr->connect = new node(13);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 7
	ptr = Map[7];
	ptr->role = 0;
	ptr->connect = new node(4);
	ptr = ptr->connect;
	ptr->connect = new node(8);
	ptr = ptr->connect;
	ptr->connect = new node(14);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 8
	ptr = Map[8];
	ptr->role = 0;
	ptr->connect = new node(4);
	ptr = ptr->connect;
	ptr->connect = new node(7);
	ptr = ptr->connect;
	ptr->connect = new node(9);
	ptr = ptr->connect;
	ptr->connect = new node(14);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 9
	ptr = Map[9];
	ptr->role = 0;
	ptr->connect = new node(5);
	ptr = ptr->connect;
	ptr->connect = new node(8);
	ptr = ptr->connect;
	ptr->connect = new node(10);
	ptr = ptr->connect;
	ptr->connect = new node(15);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 10
	ptr = Map[10];
	ptr->role = 0;
	ptr->connect = new node(5);
	ptr = ptr->connect;
	ptr->connect = new node(9);
	ptr = ptr->connect;
	ptr->connect = new node(11);
	ptr = ptr->connect;
	ptr->connect = new node(15);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//--------------------------------------------------------------
	//���|�]�m:node 11 - 20
	//--------------------------------------------------------------
	//node 11
	ptr = Map[11];
	ptr->role = 0;
	ptr->connect = new node(5);
	ptr = ptr->connect;
	ptr->connect = new node(10);
	ptr = ptr->connect;
	ptr->connect = new node(12);
	ptr = ptr->connect;
	ptr->connect = new node(15);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 12
	ptr = Map[12];
	ptr->role = 0;
	ptr->connect = new node(6);
	ptr = ptr->connect;
	ptr->connect = new node(11);
	ptr = ptr->connect;
	ptr->connect = new node(13);
	ptr = ptr->connect;
	ptr->connect = new node(16);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 13
	ptr = Map[13];
	ptr->role = 0;
	ptr->connect = new node(6);
	ptr = ptr->connect;
	ptr->connect = new node(12);
	ptr = ptr->connect;
	ptr->connect = new node(16);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 14
	ptr = Map[14];
	ptr->role = 2;
	ptr->connect = new node(7);
	ptr = ptr->connect;
	ptr->connect = new node(8);
	ptr = ptr->connect;
	ptr->connect = new node(18);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 15
	ptr = Map[15];
	ptr->role = 0;
	ptr->connect = new node(9);
	ptr = ptr->connect;
	ptr->connect = new node(10);
	ptr = ptr->connect;
	ptr->connect = new node(11);
	ptr = ptr->connect;
	ptr->connect = new node(17);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 16
	ptr = Map[16];
	ptr->role = 2;
	ptr->connect = new node(12);
	ptr = ptr->connect;
	ptr->connect = new node(13);
	ptr = ptr->connect;
	ptr->connect = new node(20);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 17
	ptr = Map[17];
	ptr->role = 2;
	ptr->connect = new node(15);
	ptr = ptr->connect;
	ptr->connect = new node(18);
	ptr = ptr->connect;
	ptr->connect = new node(19);
	ptr = ptr->connect;
	ptr->connect = new node(20);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 18
	ptr = Map[18];
	ptr->role = 2;
	ptr->connect = new node(14);
	ptr = ptr->connect;
	ptr->connect = new node(17);
	ptr = ptr->connect;
	ptr->connect = new node(19);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 19
	ptr = Map[19];
	ptr->role = 2;
	ptr->connect = new node(17);
	ptr = ptr->connect;
	ptr->connect = new node(18);
	ptr = ptr->connect;
	ptr->connect = new node(20);
	ptr = ptr->connect;
	ptr->connect = NULL;
	//node 20
	ptr = Map[20];
	ptr->role = 2;
	ptr->connect = new node(16);
	ptr = ptr->connect;
	ptr->connect = new node(17);
	ptr = ptr->connect;
	ptr->connect = new node(19);
	ptr = ptr->connect;
	ptr->connect = NULL;
	/*
	//output map
	for(int i = 0 ; i < NODESIZE ; ++i)
	{
		bool fir = true;
		node *tmp = Map[i];
		printf("%d :",tmp->nodeID);
		while(tmp->connect != NULL)
		{
			if(!fir) printf("->");
			tmp = tmp->connect;
			printf("%d",tmp->nodeID);
			fir = false;
		}
		printf("\n");
	}
	*/

}
void judge_rule(player* which_turn)//�P�_���@��
{
	//���s�p��Ҧ���m����
	calc_space();
	//�P�_�Y�ӴѤl���L�Q�Y��
	for(int i = 0 ; i < MAX_ALIVE_CHESS_NUM ; ++i)
	{
		if(which_turn->chess_position[i] == -1)continue;//�Q�Y�����N���ΦA�P�_
		if(which_turn->chess_space[i] == 0)//�p�G�Y�ӴѤl����=0
		{
			Map[which_turn->chess_position[i]]->role = 0;//�N�ѽL�Ӧ�m�ܦ��Ū�
			which_turn->chess_position[i] = -1;//�⨺�ӴѤl�Y��(�]��-1)
			which_turn->current_alive_chess_num--;//�Ӥ�Ѥl-1
		}
		if(which_turn->current_alive_chess_num <= 2)
		{
			printf("game over!!\n");
			if(which_turn->id == 1)
			{
				printf("p1 win!!!\n");
			}
			else
			{
				printf("ai win!!!\n");
			}
			system("PAUSE");
			exit(0);//�����{��
			//gameover();//gameover
		}
	}
	//�P�_�b�Y�p�魫�Ʋ���
}
void move(player* which_turn,int which_node,int node_destination)//���@��A�����Ѥl(�ѽL�s��)�A�������(�ѽL�s��)
{
	if(Map[which_node]->role != which_turn->id)//�P�_�n���ʪ��a��O�_�O�o�^�������a
	{
		printf("�D�k������:�q %d �� %d(���I���O�i�H���ʪ��Ѥl)\n",which_node,node_destination);
	}
	if(Map[node_destination]->role != 0)//�P�_�n���ʪ��ت��O�_�O�Ū�
	{
		printf("�D�k������:�q %d �� %d(���I�W����L�Ѥl)\n",which_node,node_destination);
	}
	if(calc_distance(Map[which_node],Map[node_destination]) == 1)//�P�_�O�_�i���ʨ�Ӧ�m
	{
		//�ܧ�a�ϴѤl��T
		Map[which_node]->role = 0;
		Map[node_destination]->role = which_turn->id;		
		//�ܧ󪱮a�Ѥl��T
		int temp = 0;
		for(int i = 0 ; i < MAX_ALIVE_CHESS_NUM ; ++i)
		{
			if(which_turn->chess_position[i] == which_node)
			{
				which_turn->chess_position[i] = node_destination;
				break;
			}
		}
		if(which_turn->id == 1)
		{
			
			judge_rule(p1);//�ۤv�U���A�P�_���
		}
		else
		{
			judge_rule(ai);
		}
	}
	else
	{
		printf("�D�k������:�q %d �� %d(���ʶZ������1)\n",which_node,node_destination);
	}

}
void build_game_tree(player* which_turn)
{
	int tree_level = 1;
	//player first
	for(int i = 0 ; i < MAX_ALIVE_CHESS_NUM ; ++i)
	{
		node* ptr = Map[p1->chess_position[i]];
		while(ptr->connect != NULL)
		{
			ptr = ptr->connect;
			if(Map[ptr->nodeID]->role == 0)
			{
				tree* new_node = new tree(0,p1->chess_position[i],ptr->nodeID);

			}
		}
		if(Map[p1->chess_position[i]]->connect == 0)
		{
		
		}
	}
}
void random_stupid_ai(player* which_turn)
{
	possible_state.clear();//�M�ťi�઺�U�k
	for(int i = 0 ; i < MAX_ALIVE_CHESS_NUM ; ++i)
	{
		node* ptr = Map[which_turn->chess_position[i]];
		while(ptr->connect != NULL)
		{
			ptr = ptr->connect;
			if(Map[ptr->nodeID]->role == 0)
			{
				//tree* new_node = new tree(0,p1->chess_position[i],ptr->nodeID);
				state temp(which_turn->chess_position[i],ptr->nodeID);
				possible_state.push_back(temp);//�[�J�i�઺�U�k
			}
		}
	}

	int rand_decision_num = rand() % possible_state.size();
	decision.instruction_where = possible_state.at(rand_decision_num).instruction_where;
	decision.instruction_to = possible_state.at(rand_decision_num).instruction_to;
	move(which_turn,decision.instruction_where,decision.instruction_to);
}



void stepone() {
	if (direction == 0) {
		decision.instruction_where = 16;
		decision.instruction_to = 12;
		move(p1, decision.instruction_where, decision.instruction_to);
		Round++;
	}
	if (direction == 1) {
		if ((Map[8]->role == 0 )&&(Map[4]->role == 1)) {
			decision.instruction_where = 4;
			decision.instruction_to = 8;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if ((Map[12]->role == 0)&&(Map[6]->role == 1)) {
			decision.instruction_where = 6;
			decision.instruction_to = 12;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		Round++;
	}
}

void steptwo() {
	if (direction == 0) {
		if (Map[13]->role == 1 && Map[16]->role == 0 && Map[20]->role == 2) {
			decision.instruction_where = 20;
			decision.instruction_to = 16;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[8]->role == 0 && Map[14]->role == 2) {
			decision.instruction_where = 14;
			decision.instruction_to = 8;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else {
			if (Map[15]->role == 0 && Map[17]->role == 2) {
				decision.instruction_where = 17;
				decision.instruction_to = 15;
				move(p1, decision.instruction_where, decision.instruction_to);
			}
		}
		Round++;
	}
	if (direction == 1) {
		if (Map[13]->role == 2 && Map[6]->role == 0 && Map[2]->role == 1) {
			decision.instruction_where = 2;
			decision.instruction_to = 6;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[8]->role == 0 && Map[4]->role == 1) {
			decision.instruction_where = 4;
			decision.instruction_to = 8;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[12]->role == 0 && Map[6]->role == 1) {
			decision.instruction_where = 6;
			decision.instruction_to = 12;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else {
			if (Map[5]->role == 0 && Map[3]->role == 1) {
				decision.instruction_where = 3;
				decision.instruction_to = 5;
				move(ai, decision.instruction_where, decision.instruction_to);
			}
		}
		Round++;
	}
}

void stepthree() {
	if (direction == 0) {
		if (Map[8]->role == 0 && Map[14]->role == 2) {
			decision.instruction_where = 14;
			decision.instruction_to = 8;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[13]->role == 1 && Map[16]->role == 0 && Map[20]->role == 2) {
			decision.instruction_where = 20;
			decision.instruction_to = 16;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[7]->role == 1 && Map[14]->role == 0 && Map[18]->role == 2) {
			decision.instruction_where = 18;
			decision.instruction_to = 14;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[17]->role == 0 && Map[19]->role == 2) {
			decision.instruction_where = 19;
			decision.instruction_to = 17;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else {
			if (Map[15]->role == 0 && Map[17]->role == 2) {
				decision.instruction_where = 17;
				decision.instruction_to = 15;
				move(p1, decision.instruction_where, decision.instruction_to);
			}
		}
		Round++;
	}
	if (direction == 1) {
		if (Map[12]->role == 0 && Map[6]->role == 1) {
			decision.instruction_where = 6;
			decision.instruction_to = 12;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[8]->role == 0 && Map[4]->role == 1) {
			decision.instruction_where = 4;
			decision.instruction_to = 8;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[13]->role == 2 && Map[6]->role == 0 && Map[2]->role == 1) {
			decision.instruction_where = 2;
			decision.instruction_to = 6;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[7]->role == 2 && Map[4]->role == 0 && Map[0]->role == 1) {
			decision.instruction_where = 0;
			decision.instruction_to = 4;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[3]->role == 0 && Map[1]->role == 1) {
			decision.instruction_where = 1;
			decision.instruction_to = 3;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else {
			if (Map[5]->role == 0 && Map[3]->role == 1) {
				decision.instruction_where = 3;
				decision.instruction_to = 5;
				move(ai, decision.instruction_where, decision.instruction_to);
			}
		}
		Round++;
	}
}

void stepfour() {
	if (direction == 0) {
		if (Map[7]->role == 1 && Map[14]->role == 0 && Map[18]->role == 2) {
			decision.instruction_where = 18;
			decision.instruction_to = 14;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[13]->role == 1 && Map[16]->role == 0 && Map[20]->role == 2) {
			decision.instruction_where = 20;
			decision.instruction_to = 16;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (((Map[9]->role == 1) || (Map[10]->role == 1) || (Map[11]->role == 1)) && (Map[15]->role == 0 && Map[17]->role == 2)) {
			decision.instruction_where = 17;
			decision.instruction_to = 15;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[19]->role == 2 && Map[17]->role == 0 && Map[19]->role == 2) {
			decision.instruction_where = 19;
			decision.instruction_to = 17;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else {
			if ((Map[15]->role == 0) && (Map[17]->role == 2)) {
				decision.instruction_where = 17;
				decision.instruction_to = 15;
				move(p1, decision.instruction_where, decision.instruction_to);
			}
			else {
				if ((Map[17]->role == 0) && (Map[19]->role == 2)) {
					decision.instruction_where = 19;
					decision.instruction_to = 17;
					move(p1, decision.instruction_where, decision.instruction_to);
				}
				center();
			}
		}
		Round++;
	}
	if (direction == 1) {
		if (Map[7]->role == 2 && Map[4]->role == 0 && Map[0]->role == 1) {
			decision.instruction_where = 0;
			decision.instruction_to = 4;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[13]->role == 2 && Map[6]->role == 0 && Map[2]->role == 1) {
			decision.instruction_where = 2;
			decision.instruction_to = 6;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (((Map[9]->role == 2) || (Map[10]->role == 2) || (Map[11]->role == 2)) && (Map[5]->role == 0 && Map[3]->role == 1)) {
			decision.instruction_where = 3;
			decision.instruction_to = 5;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[1]->role == 1 && Map[3]->role == 0) {
			decision.instruction_where = 1;
			decision.instruction_to = 3;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else {
			if (Map[5]->role == 0 && Map[3]->role == 1) {
				decision.instruction_where = 3;
				decision.instruction_to = 5;
				move(ai, decision.instruction_where, decision.instruction_to);
			}
			else {
				if ((Map[3]->role == 0) && (Map[1]->role == 2)) {
					decision.instruction_where = 1;
					decision.instruction_to = 3;
					move(p1, decision.instruction_where, decision.instruction_to);
				}
				center();
			}
		}
		Round++;
	}
}

void stepfive(){
	if (direction == 0) {
		if (Map[7]->role == 1 && Map[14]->role == 0 && Map[18]->role == 2) {
			decision.instruction_where = 18;
			decision.instruction_to = 14;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[13]->role == 1 && Map[16]->role == 0 && Map[20]->role == 2) {
			decision.instruction_where = 20;
			decision.instruction_to = 16;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (((Map[9]->role == 1) || (Map[10]->role == 1) || (Map[11]->role == 1)) && (Map[15]->role == 0) && Map[17]->role == 2) {
			decision.instruction_where = 17;
			decision.instruction_to = 15;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if ((Map[14]->role == 2) && (Map[16]->role == 2) && Map[17]->role == 0 && Map[19]->role == 2) {
			decision.instruction_where = 19;
			decision.instruction_to = 17;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else {
			if ((Map[15]->role == 0)&&(Map[17]->role == 2)) {
				decision.instruction_where = 17;
				decision.instruction_to = 15;
				move(p1, decision.instruction_where, decision.instruction_to);
			}
			else {
				if ((Map[17]->role == 0) && (Map[19]->role == 2)) {
					decision.instruction_where = 19;
					decision.instruction_to = 17;
					move(p1, decision.instruction_where, decision.instruction_to);
				}
				center();
			}
		}
		Round++;
	}
	if (direction == 1) {
		if (Map[7]->role == 2 && Map[4]->role == 0 && Map[0]->role == 1) {
			decision.instruction_where = 0;
			decision.instruction_to = 4;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[13]->role == 2 && Map[6]->role == 0 && Map[2]->role == 1) {
			decision.instruction_where = 2;
			decision.instruction_to = 6;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if (((Map[9]->role == 2) || (Map[10]->role == 2) || (Map[11]->role == 2)) && (Map[5]->role == 0) && Map[3]->role == 1) {
			decision.instruction_where = 3;
			decision.instruction_to = 5;
			move(ai, decision.instruction_where, decision.instruction_to);
		}
		else if ((Map[4]->role == 1) && (Map[6]->role == 1) && Map[3]->role == 0 && Map[1]->role == 1) {
			decision.instruction_where = 1;
			decision.instruction_to = 3;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else {
			if (Map[5]->role == 0 && Map[3]->role == 1) {
				decision.instruction_where = 3;
				decision.instruction_to = 5;
				move(ai, decision.instruction_where, decision.instruction_to);
			}
			else {
				if ((Map[3]->role == 0) && (Map[1]->role == 2)) {
					decision.instruction_where = 1;
					decision.instruction_to = 3;
					move(p1, decision.instruction_where, decision.instruction_to);
				}
				center();
			}
		}
		Round++;
	}
}

void center() {
	if (direction == 0) {
		if (Map[8]->role == 0 && Map[14]->role == 2) {
			decision.instruction_where = 14;
			decision.instruction_to = 8;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else if (Map[7]->role == 1 && Map[14]->role == 0 && Map[18]->role == 2) {
			decision.instruction_where = 18;
			decision.instruction_to = 14;
			move(p1, decision.instruction_where, decision.instruction_to);
		}
		else {
			while (1) {
				int i = 0, j = 0;
				int t = rand() % 4;
				if (t == 0) {
					i = 9;
				}
				else if (t == 1) {
					i = 10;
				}
				else if (t == 2) {
					i = 11;
				}
				else if (t == 3) {
					i = 15;
				}
				int p = rand() % 2;
				if (p == 0) {
					if (Map[5]->role == 0) {
						if (calc_distance(Map[currentp1], Map[5]) == 1) {
							decision.instruction_where = currentp1;
							decision.instruction_to = 5;
							move(p1, decision.instruction_where, decision.instruction_to);
							currentp1 = 5;
							break;
						}
						else {

						}
					}
					if (Map[i]->role == 0) {
						if (calc_distance(Map[currentp1], Map[i]) == 1) {
							decision.instruction_where = currentp1;
							decision.instruction_to = i;
							move(p1, decision.instruction_where, decision.instruction_to);
							currentp1 = i;
							break;
						}
						else {
							continue;
						}
					}
				}
				else if (p == 1) {
					if (Map[5]->role == 0) {
						if (calc_distance(Map[currentp2], Map[5]) == 1) {
							decision.instruction_where = currentp2;
							decision.instruction_to = 5;
							move(p1, decision.instruction_where, decision.instruction_to);
							currentp2 = 5;
							break;
						}
						else {

						}
					}
					if (Map[i]->role == 0) {
						if (calc_distance(Map[currentp2], Map[i]) == 1) {
							decision.instruction_where = currentp2;
							decision.instruction_to = i;
							move(p1, decision.instruction_where, decision.instruction_to);
							currentp2 = i;
							break;
						}
						else {
							continue;
						}
					}
				}
			}
		}
	}
	if (direction == 1) {
		if (direction == 0) {
			if (Map[8]->role == 0 && Map[4]->role == 1) {
				decision.instruction_where = 4;
				decision.instruction_to = 8;
				move(ai, decision.instruction_where, decision.instruction_to);
			}
			else if (Map[12]->role == 0 && Map[6]->role == 1) {
				decision.instruction_where = 6;
				decision.instruction_to = 12;
				move(ai, decision.instruction_where, decision.instruction_to);
			}
			else if (Map[7]->role == 2 && Map[14]->role == 0 && Map[18]->role == 1) {
				decision.instruction_where = 18;
				decision.instruction_to = 14;
				move(ai, decision.instruction_where, decision.instruction_to);
			}
			else if (Map[13]->role == 2 && Map[12]->role == 0 && Map[6]->role == 1) {
				decision.instruction_where = 6;
				decision.instruction_to = 12;
				move(ai, decision.instruction_where, decision.instruction_to);
			}
			else {
				while (1) {
					int i = 0, j = 0;
					int t = rand() % 4;
					if (t == 0) {
						i = 9;
					}
					else if (t == 1) {
						i = 10;
					}
					else if (t == 2) {
						i = 11;
					}
					else if (t == 3) {
						i = 5;
					}
					int p = rand() % 2;
					if (p == 0) {
						if (Map[15]->role == 0) {
							if (calc_distance(Map[currentpI], Map[15]) == 1) {
								decision.instruction_where = currentpI;
								decision.instruction_to = 15;
								move(ai, decision.instruction_where, decision.instruction_to);
								currentpI = 15;
								break;
							}
							else {

							}
						}
						if (Map[i]->role == 0) {
							if (calc_distance(Map[currentpI], Map[i]) == 1) {
								decision.instruction_where = currentpI;
								decision.instruction_to = i;
								move(ai, decision.instruction_where, decision.instruction_to);
								currentpI = i;
								break;
							}
							else {
								continue;
							}
						}
					}
					else if (p == 1) {
						if (Map[15]->role == 0) {
							if (calc_distance(Map[currentpII], Map[15]) == 1) {
								decision.instruction_where = currentpII;
								decision.instruction_to = 15;
								move(ai, decision.instruction_where, decision.instruction_to);
								currentpII = 15;
								break;
							}
							else {

							}
						}
						if (Map[i]->role == 0) {
							if (calc_distance(Map[currentpII], Map[i]) == 1) {
								decision.instruction_where = currentpII;
								decision.instruction_to = i;
								move(ai, decision.instruction_where, decision.instruction_to);
								currentpII = i;
								break;
							}
							else {
								continue;
							}
						}
					}
				}
			}

		}
	}
}

/*void attack() {
		for (int i = 0; i < 21; i++) {
			if (Map[i]->role == 0) {
				for (int j = 0; j < 21; j++) {
					if ((Map[j]->role == 2)&&(calc_distance(Map[j], Map[i]) == 1)&&(j>i)) {
							decision.instruction_where = j;
							decision.instruction_to = i;
							move(p1, decision.instruction_where, decision.instruction_to);
							break;
						}
						else {
							for (int s = 20; s >= 0; s--) {
								if (Map[s]->role == 0) {
									for (int t = 20; t >= 0; t--) {
										if ((calc_distance(Map[t], Map[s]) == 1) && (Map[t]->role == 2)) {
											decision.instruction_where = t;
											decision.instruction_to = s;
											move(p1, decision.instruction_where, decision.instruction_to);
											break;
										}
									}
								}
							}
							break;
						}
					}
				}
			}
		Round++;
}*/

void little_smart_ai()//���I�o����AI
{
	//����:AI�b�U��(p1�B)
	if(Round == 1)stepone();
	else if(Round == 2)steptwo();
	else if(Round == 3)stepthree();
	else if(Round == 4)stepfour();
	else if(Round == 5)stepfive();
	else if(Round >= 6)center();
	//else if (Round >= 6)attack();
	else
	{
		printf("ERROR?!\n");
		getchar();
	}
}




int main()
{
	init();
	//test_distance();
	//getchar();
	printf("�֥��U? 1.ai(�W��)���U 2.���a(�U��)���U 3.ai(�U��)���U 4.ai(�W��)��U:\n");
	int n = 0;
	int ai_orgin = 0,ai_destination = 0;
	int p1_orgin = 0,p1_destination = 0;
	while(true)
	{
		scanf("%d",&n);
		switch(n)
		{
			case 1:
				while(true)
				{
					system("cls");
					//printf("ai�U��?\n");
					//scanf("%d %d",&ai_orgin,&ai_destination);
					//move(ai,ai_orgin,ai_destination);//���@��A�����Ѥl(�ѽL�s��)�A�������(�ѽL�s��)	
					random_stupid_ai(ai);
					printMap();
					printf("ai������:�q %d �� %d\n",decision.instruction_where,decision.instruction_to);

					printf("p1�U��?\n");
					scanf("%d %d",&p1_orgin,&p1_destination);
					move(p1,p1_orgin,p1_destination);//���@��A�����Ѥl(�ѽL�s��)�A�������(�ѽL�s��)
					printf("p1������:�q %d �� %d\n",p1_orgin,p1_destination);
				}
				break;
			case 2:
				while(true)
				{
					printMap();
					printf("p1�U��?\n");
					scanf("%d %d",&p1_orgin,&p1_destination);
					system("cls");
					move(p1,p1_orgin,p1_destination);//���@��A�����Ѥl(�ѽL�s��)�A�������(�ѽL�s��)	
					printf("p1������:�q %d �� %d\n",p1_orgin,p1_destination);

					//printf("ai�U��?\n");
					//scanf("%d %d",&ai_orgin,&ai_destination);
					//move(ai,ai_orgin,ai_destination);//���@��A�����Ѥl(�ѽL�s��)�A�������(�ѽL�s��)	
					
					random_stupid_ai(ai);	
					printf("ai������:�q %d �� %d\n",decision.instruction_where,decision.instruction_to);
				}
				break;
			case 3:
				while (true)
				{
					direction = 0;
					//random_stupid_ai(p1);
					little_smart_ai();
					printMap();
					printf("ai������:�q %d �� %d\n", decision.instruction_where, decision.instruction_to);

					printf("p1�U��?\n");


					//>>-------------�P�_��J is ���` �X�k��<<-------------------
					while (true) {

						scanf("%d %d", &p1_orgin, &p1_destination);

						if (Map[p1_orgin]->role == 1 && Map[p1_destination]->role == 0)
						{
							printf("�X�k����J\n");
							//printf("�X�k�q %d �� %d\n",decision.instruction_where,decision.instruction_to);
							break;
						}
						else
						{
							printf("���X�k����J\n");
							//printf("���X�k�q %d �� %d\n",decision.instruction_where,decision.instruction_to);
							continue;
						}
					}
					//------------------------------------------------------------


					move(ai, p1_orgin, p1_destination);//���@��A�����Ѥl(�ѽL�s��)�A�������(�ѽL�s��)
					printf("p1������:�q %d �� %d\n", p1_orgin, p1_destination);
				}
				break;
			case 4:
				while (true)
				{
					printMap();
					printf("p1�U��?\n");
					scanf("%d %d", &p1_orgin, &p1_destination);
					system("cls");
					move(p1, p1_orgin, p1_destination);//���@��A�����Ѥl(�ѽL�s��)�A�������(�ѽL�s��)
					printf("p1������:�q %d �� %d\n", p1_orgin, p1_destination);

					//random_stupid_ai(p1);
					direction = 1;
					little_smart_ai();
					printf("ai������:�q %d �� %d\n", decision.instruction_where, decision.instruction_to);
				}
				break;
				
			default:
				printf("���~��J!�Э��s��J!!\n");
		}
	}

	system("PAUSE");
	return 0;
}